<?php
// Optional PHP entry point. Run from the project root with:
// php -S localhost:8000 -t php
// This starter serves the same static frontend. Add real database-backed auth before launch.
$path = __DIR__ . '/../public/index.html';
if (file_exists($path)) {
    readfile($path);
} else {
    http_response_code(404);
    echo "Frontend not found.";
}
?>
