// Node.js / Express server
// Run: npm install && npm start
const express = require("express");
const path = require("path");
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (_req, res) => res.json({ ok: true, app: "CineWave" }));

// Demo-only authentication endpoint. Replace with a real database,
// password hashing (bcrypt/argon2), sessions, and validation before production.
const demoUsers = new Map();

app.post("/api/register", (req, res) => {
  const { name, email, password } = req.body || {};
  if (!name || !email || !password || password.length < 6) {
    return res.status(400).json({ error: "Enter a name, valid email and password (6+ characters)." });
  }
  const key = String(email).toLowerCase();
  if (demoUsers.has(key)) return res.status(409).json({ error: "That email is already registered." });
  demoUsers.set(key, { name: String(name).slice(0, 50), email: key, password: String(password), vip: false });
  res.status(201).json({ user: { name: demoUsers.get(key).name, email: key, vip: false } });
});

app.post("/api/login", (req, res) => {
  const { email, password } = req.body || {};
  const user = demoUsers.get(String(email || "").toLowerCase());
  if (!user || user.password !== password) return res.status(401).json({ error: "Email or password is incorrect." });
  res.json({ user: { name: user.name, email: user.email, vip: user.vip } });
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`CineWave running at http://localhost:${PORT}`));
