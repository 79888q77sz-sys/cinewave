# CineWave streaming website starter

A responsive, Netflix-inspired streaming UI built with HTML, CSS and vanilla JavaScript. It includes a sign-in/register screen, profile menu, search, free and VIP title rows, title details, a My List interaction, and a demo VIP toggle.

## Run with Node.js (recommended)

1. Install Node.js 18+.
2. Open a terminal in this folder.
3. Run:

```bash
npm install
npm start
```

4. Visit http://localhost:3000

You can also run `node server.js` after installing Express.

## PHP option

The `php/index.php` file is a minimal alternative static entry point. From the project root run:

```bash
php -S localhost:8000 -t php
```

Then visit http://localhost:8000. The PHP entry point serves the frontend only; the included login API is provided by the Node server. For a PHP-backed production app, implement the auth endpoints using PHP and a database.

## Files

- `public/index.html` — page structure
- `public/styles.css` — responsive visual design
- `public/app.js` — UI interactions and demo auth calls
- `server.js` — Express server and demo API
- `app.js` — alternate Node entry point
- `php/index.php` — optional PHP static entry point

## Important before production

This is a front-end starter, not a production streaming service. The Node demo stores users in memory and compares plain-text demo passwords. It loses accounts when the server restarts and is **not secure**. Before public launch, use a database, hash passwords with bcrypt or Argon2, add secure sessions/cookies, CSRF protection, rate limiting, input validation, HTTPS, and proper account recovery. Implement real VIP subscriptions with a payment provider and server-side entitlement checks. Use only films and artwork you own or are licensed to stream. The video player is intentionally a placeholder: connect it to your authorized HLS/DASH or MP4 sources.
