// Optional alternative entry-point name. Uses the same Express app as server.js.
require("./server");
